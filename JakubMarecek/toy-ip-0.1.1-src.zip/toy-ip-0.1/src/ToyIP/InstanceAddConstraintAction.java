package ToyIP;

import ToyIP.*;

import java.io.*;
import java.awt.*;
import java.awt.event.*;
import java.util.*;
import javax.swing.*;
import javax.swing.event.*;
import javax.swing.table.*;


class InstanceAddConstraintAction extends AbstractAction {

  protected AppletSettings app;

  public InstanceAddConstraintAction(AppletSettings a) {
    super("Add Constraint");
    app = a;
  }

  public void actionPerformed(ActionEvent ae) {
    app.instanceAddConstraint(0, 0, 0, 100);
  }
}
