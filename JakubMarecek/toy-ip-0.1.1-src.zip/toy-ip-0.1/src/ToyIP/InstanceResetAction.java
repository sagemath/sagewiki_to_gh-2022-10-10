package ToyIP;

import ToyIP.*;

import java.io.*;
import java.awt.*;
import java.awt.event.*;
import java.util.*;
import javax.swing.*;
import javax.swing.event.*;
import javax.swing.table.*;


public class InstanceResetAction extends AbstractAction {

  protected AppletSettings app;

  public InstanceResetAction(AppletSettings a) {
    super("Clear");
    app = a;
  }

  public void actionPerformed(ActionEvent ae) {
    app.instanceReset();
  }
}

