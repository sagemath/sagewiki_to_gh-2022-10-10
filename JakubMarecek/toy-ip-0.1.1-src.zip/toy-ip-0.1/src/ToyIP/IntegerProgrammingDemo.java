package ToyIP;

import ToyIP.*;

import java.io.*;
import java.awt.*;
import javax.swing.*;


public class IntegerProgrammingDemo {

  public static void main(String s[]) {
    JFrame rendererFrame = new JFrame("Renderer");
    rendererFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    AppletRenderer rendererPanel = new AppletRenderer();
    rendererFrame.setContentPane(rendererPanel);
    rendererFrame.pack();
    rendererFrame.setLocation(0, 0);
    rendererFrame.setVisible(true);

    JFrame controlFrame = new JFrame("Toy Integer Programming Solver");
    controlFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    AppletSettings controlPanel = new AppletSettings(rendererPanel);
    controlPanel.init();
    controlFrame.setContentPane(controlPanel);
    controlFrame.pack();
    controlFrame.setLocation(510, 0);
    controlFrame.setVisible(true);
  }
}
