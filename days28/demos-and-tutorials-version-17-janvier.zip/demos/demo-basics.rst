.. _demo-basics:

=====================
Demonstration: Basics
=====================

::

    sage: %hide
    sage: pretty_print_default()

Arithmetic::

    sage: 1 + 1

    sage: factor(x^100 - 1)

Symbolic calculations::

    sage: var('y')
    sage: f = sin(x) - cos(x*y) + 1 / (x^3+1)
    sage: f

::

    sage: f.integrate(x)

.. Next example taken from Calcul mathématique avec Sage

::

    sage: expr = sin(x) + sin(2 * x) + sin(3 * x)
    sage: solve(expr, x)
    [sin(3*x) == -sin(2*x) - sin(x)]

.. No solution!
.. Numeric solution:

::

    sage: find_root(expr, 0.1, pi)
    2.0943951023931957

.. Simplication + exact solution

::

    sage: f = expr.simplify_trig(); f
    2*(2*cos(x)^2 + cos(x))*sin(x)
    sage: solve(f, x)
    [x == 0, x == 2/3*pi, x == 1/2*pi]

Statistics::

    sage: print r.summary(r.c(1,2,3,111,2,3,2,3,2,5,4))


.. TODO: other examples from MuPAD-Combinat/lib/DOC/demo/mupad.tex
