Loops and Iterators
===================

List comprehensions ::

    sage: [ i^2 for i in [1, 3, 7] ]
    [1, 9, 49]

    sage: [ i^2 for i in range(1,10) ]
    [1, 4, 9, 16, 25, 36, 49, 64, 81]


    sage: [ i^2 for i in range(1,10) if not is_prime(i) ]
    [4, 9, 25, 49]

    sage: [ (i,j) for i in range(1,6) for j in range(1,i) ]
    [(2, 1), (3, 1), (3, 2), (4, 1), (4, 2), (4, 3), (5, 1), (5, 2), (5, 3), (5, 4)]

    sage: [ [ binomial(n, i) for i in range(n+1) ] for n in range(10) ]
    [[1],
    [1, 1],
    [1, 2, 1],
    [1, 3, 3, 1],
    [1, 4, 6, 4, 1],
    [1, 5, 10, 10, 5, 1],
    [1, 6, 15, 20, 15, 6, 1],
    [1, 7, 21, 35, 35, 21, 7, 1],
    [1, 8, 28, 56, 70, 56, 28, 8, 1],
    [1, 9, 36, 84, 126, 126, 84, 36, 9, 1]]


    Iterators ::

    sage: it = (binomial(8, i) for i in range(9))
    sage: it.next()
    1

    sage: it.next()
    8

    sage: sum( [ binomial(8, i) for i in range(9) ] )
    256

    sage: sum( binomial(8, i) for i in xrange(9) )
    256


Typical uses of iterators::

    sage: all([True, True, True, True])
    True

    sage: all([True, False, True, True])
    False

    sage: any([False, False, False, False])
    False
    sage: any([False, False, True, False])
    True

    sage: all( is_odd(p) for p in range(1,100) if is_prime(p) and p>2 )
    True

    sage: def mersenne(p): return 2^p -1
    sage: [ is_prime(p) for p in range(20) if is_prime(mersenne(p)) ]
    [True, True, True, True, True, True, True, True]

    sage: all( is_prime(mersenne(p)) for p in range(1000) if is_prime(p) )
    False
    sage: all( [ is_prime(mersenne(p)) for p in range(1000) if is_prime(p)] )
    False

    sage: exists( (p for p in range(1000) if is_prime(p)), lambda p: not is_prime(mersenne(p)) )

    sage: contre_exemples = (p for p in range(1000) if is_prime(p) and not is_prime(mersenne(p)))
    sage: contre_exemples.next()

    sage: cubes = [t**3 for t in range(-10,11)]
    sage: exists([(x,y) for x in cubes for y in cubes], lambda (x,y): x+y == 218)

    sage: exists(((x,y) for x in cubes for y in cubes), lambda (x,y): x+y == 218)

complexite memoire?


itertools::

    sage: import itertools

    sage: [(i, cubes[i]) for i in range(len(cubes))]

    sage: list(enumerate(cubes))

    sage: list(Permutations(3))

    sage: list(itertools.islice(Permutations(3), 1, 4))

    sage: list(itertools.imap(lambda z: z.cycle_type(), Permutations(3)))

    sage: list(itertools.ifilter(lambda z: z.has_pattern([1,2]), Permutations(3)))


Defining new iterators::


    sage: def f(n):
    ...     for i in range(n):
    ...         yield i
    sage: [ x for x in f(5) ]
    [0, 1, 2, 3, 4]


    sage: def words(alphabet,l):
    ...      if l == 0:
    ...          yield []
    ...      else:
    ...          for word in words(alphabet, l-1):
    ...              for a in alphabet:
    ...                  yield word + [a]

    sage: [ w for w in words(['a','b','c'], 3) ]

    sage: sum(1 for w in words(['a','b','c'], 3))

    sage: def dyck_words(l):
    ...       if l==0:
    ...           yield ''
    ...       else:
    ...           for k in range(l):
    ...               for w1 in dyck_words(k):
    ...                   for w2 in dyck_words(l-k-1):
    ...                       yield '('+w1+')'+w2

    sage: list(dyck_words(4))
    ['()()()()',
    '()()(())',
    '()(())()',
    '()(()())',
    '()((()))',
    '(())()()',
    '(())(())',
    '(()())()',
    '((()))()',
    '(()()())',
    '(()(()))',
    '((())())',
    '((()()))',
    '(((())))']

    sage: sum(1 for w in dyck_words(5))
    42


Standard Iterables::

    sage: sum( x^len(s) for s in Subsets(8) )
    x^8 + 8*x^7 + 28*x^6 + 56*x^5 + 70*x^4 + 56*x^3 + 28*x^2 + 8*x + 1

    sage: sum( x^p.length() for p in Permutations(3) )

    sage: factor(sum( x^p.length() for p in Permutations(3) ))

    sage: P = Permutations(5)
    sage: all( p in P for p in P )
    True

    sage: for p in GL(2, 2): print p; print

    sage: for p in Partitions(3): print p

    sage: for p in Partitions(): print p

    sage: for p in Primes(): print p

    sage: exists( Primes(), lambda p: not is_prime(mersenne(p)) )
    (True, 11)


    sage: contre_exemples = (p for p in Primes() if not is_prime(mersenne(p)))
    sage: contre_exemples.next()
    11
