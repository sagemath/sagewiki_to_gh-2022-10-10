.. _demos.index:

=================================
Index of Sage demos and tutorials
=================================

Thematic demos
==============

.. toctree::
    :maxdepth: 1

    demo-basics.rst
    ../sage/plot/demo.rst
    demo-doc.rst
    demo-constructions-categories-short.rst
    demo-cython.rst
    demo-databases.rst
    demo-combinatorics.rst
    demo-algebraic-combinatorics.rst
    demo-iterator.rst
    demo-sage-combinat.rst
    demo-GAP3-Semigroupe.rst
    demo-monoids-character_rings.rst
    demo-monoids-jtrivial.rst
    demo-origamis
    demo-words

Thematic tutorials
==================

Introduction to Sage
--------------------

* :ref:`tutorial-notebook-and-help`
* :ref:`tutorial-notebook-and-help-long`
* :ref:`tutorial-first-exercises` (outdated)

* `Sage's main tutorial <http:../../tutorial/>`_

Combinatorics
-------------

* :ref:`tutorial-basic-combinatorics`
* `Tutorial: Interval exchanges <http:../../thematic_tutorials/interval_exchanges.html>`_
* `Tutorial: Lie Methods and Related Combinatorics in Sage <http:../../thematic_tutorials/lie.html>`_
* `Tutorial: Linear Programming (Mixed Integer) <http:../../thematic_tutorials/linear_programming.html>`_
* `Tutorial: Group Theory <http:../../thematic_tutorials/group_theory.html>`_

* :ref:`tutorial-using-free-modules`
* :ref:`tutorial-implementing-algebraic-structures`

Programming
-----------

* :ref:`tutorial-programming-python`
* :ref:`tutorial-objects-and-classes`
* `Tutorial: Functional Programming for Mathematicians <http:../../thematic_tutorials/functional_programming.html>`_


Some talks
==========

2011:
-----

* :ref:`demo.2011-01-17-SageDays28`

2010:
-----

* :ref:`demo.2010-12-11-Nikolaus`
* :ref:`demo.2010-09-01-LACIM`
* :ref:`demo.2010-08-03-FPSAC`
* :ref:`demo.2010-07-07-Toronto`
* :ref:`demo.2010-06-14-Sage-demo-Orsay`
* :ref:`demo.2010-06-11-demo-LAGA`
* :ref:`demo.2010-05-06-SageDays20.5`
* :ref:`demo.2010-03-29-SLC64`
