.. _tutorial-first-exercises:

=========================
Tutorial: First exercises
=========================

Go to the ``File`` menu, and select ``Load worksheet from a file`` to upload the
worksheet from the following URL: ``http://wiki.sagemath.org/days20.5/schedule?action=AttachFile&do=get&target=SageDays20.5-Exercises.sws``

Then run through the exercises there. Ask for help whenever needed!

Note: this tutorial has been superseded by
:ref:`tutorial-notebook-and-help-long` which is self contained.
