.. _tutorial-objects-and-classes:

================================================
Tutorial: Objects and Classes in Python and Sage
================================================

:AUTHOR: Florent Hivert <florent.hivert@univ-rouen.fr>

This tutorial is an introduction to object oriented programming in Python and
Sage. It requires basic knowledges on imperative/procedural programming (the
most common programming style) that is conditional instructions, loops,
functions (see :ref:`tutorial-programming-python`), but now further knowledge
about objects and classes is assumed. It is designed as an alternating
sequence of formal introduction and exercises. :ref:`solutions` are given at
the end.



Object oriented programming paradigm
====================================

The object oriented programming paradigm relies on the two following
fundamental rules:

1. Any thing of the real (or mathematical) world which needs to be manipulated
   by the computer is modeled by an **object**.

#. Each object is an **instance** of some **class**.

At this point, those two rules are a little meaningless, so let's give some
more or less precise definition of the terms:

--------------------

**object**
   a **portion of memory** which contains the information needed to model
   the real world thing.

**class**
   defines the **data structure** used to store the objects which are instance
   of the class together with their **behavior**.

--------------------

Let's start with some examples: We consider the vector space over `\QQ` whose
basis is indexed by permutations, and a particular element in it::

    sage: F = CombinatorialFreeModule(QQ, Permutations())
    sage: el = 3*F([1,3,2])+ F([1,2,3])
    sage: el
    B[[1, 2, 3]] + 3*B[[1, 3, 2]]

In python, everything is an object so there isn't any difference between types
and classes. On can get the class of the object ``el`` by:

.. link

::

    sage: type(el)
    <class 'sage.combinat.free_module.CombinatorialFreeModule_with_category.element_class'>

As such, this is not very informative. We'll go back to it later. The data
associated to objects are stored in so called **attributes**. They are
accessed through the syntax ``obj.attributes_name``:

.. link

::

    sage: el._monomial_coefficients
    {[1, 2, 3]: 1, [1, 3, 2]: 3}

Modifying the attribute modifies the objects:

.. link

::

    sage: el._monomial_coefficients[Permutation([3,2,1])] = 1/2
    sage: el
    B[[1, 2, 3]] + 3*B[[1, 3, 2]] + 1/2*B[[3, 2, 1]]

.. warning:: as a user, you are *not* supposed to do that by yourself (see
             note on :ref:`private attributes <private_attributes>` below).

As an element of a vector space ``el`` has a particular behavior:

.. link

::

    sage: 2*el
    2*B[[1, 2, 3]] + 6*B[[1, 3, 2]] + B[[3, 2, 1]]
    sage: el.support()
    [[1, 2, 3], [1, 3, 2], [3, 2, 1]]
    sage: el.coefficient([1, 2, 3])
    1

The behavior is defined through **methods** (``support, coefficient``). Note
that this is true, even for equality, printing or mathematical operations. For
example the call ``a == b`` actually is translated to the method call
``a.__eq__(b)``. The names of those special methods which are usually called
through operators are fixed by the Python language and are of the form
``__name__``. Example include ``__eq__``, ``__le__`` for operators ``==`` and
``<=``, ``__repr__`` (see :ref:`sage_specifics`) for printing, ``__add__`` and
``__mult__`` for operators ``+`` and ``*`` (see
http://docs.python.org/library/) for a complete list:

.. link

::

    sage: el.__eq__(F([1,3,2]))
    False
    sage: el.__repr__()
    'B[[1, 2, 3]] + 3*B[[1, 3, 2]] + 1/2*B[[3, 2, 1]]'
    sage: el.__mul__(2)
    2*B[[1, 2, 3]] + 6*B[[1, 3, 2]] + B[[3, 2, 1]]

Some particular actions allows to modify the data structure of ``el``:

.. link

::

    sage: el.rename("bla")
    sage: el
    bla

.. note::

    The class is stored in a particular attribute called ``__class__`` the
    normal attribute are stored in a dictionary called ``__dict__``:

    .. link

    ::

       sage: F = CombinatorialFreeModule(QQ, Permutations())
       sage: el = 3*F([1,3,2])+ F([1,2,3])
       sage: el.rename("foo")
       sage: el.__class__
        <class 'sage.combinat.free_module.CombinatorialFreeModule_with_category.element_class'>
       sage: el.__dict__
       {'_monomial_coefficients': {[1, 2, 3]: 1, [1, 3, 2]: 3}, '__custom_name': 'foo'}


    Lots of sage objects are not Python objects but compiled Cython
    objects. Python sees them as builtin objects and you don't have access to
    the data structure. Examples include integers and permutation group
    elements:

    .. link

    ::

        sage: e = Integer(9)
        sage: type(e)
        <type 'sage.rings.integer.Integer'>
        sage: e.__dict__
        <dictproxy object at 0x...>
        sage: e.__dict__.keys()
        ['__module__', '_reduction', '__doc__', '_sage_src_lines_']

        sage: id4 = SymmetricGroup(4).one()
        sage: type(id4)
        <type 'sage.groups.perm_gps.permgroup_element.PermutationGroupElement'>
        sage: id4.__dict__
        <dictproxy object at 0x...>

.. note::

    Each objects corresponds to a portion of memory called its **identity** in
    python. You can get the identity using ``id``:

    .. link

    ::

        sage: el = Integer(9)
        sage: id(el)  # random
        139813642977744
        sage: el1 = el; id(el1) == id(el)
        True
	sage: el1 is el
	True

    This is different from mathematical identity:
    
    .. link

    ::

	sage: el2 = Integer(9)
	sage: el2 == el1
	True
	sage: el2 is el1
        False
	sage: id(el2) == id(el)
	False

Summary
-------

To define some object, you first have to write a **class**. The class will
defines the methods and the attributes of the object.

**method**
   particular kind of function associated with an object used to get
   information about the object or to manipulate it.

**attribute**
   variables where the info about the object are stored;



An example: glass of beverage in a restaurant
-----------------------------------------------

Let's write a small class about glasses in a restaurant::

    sage: class Glass(object):
    ...       def __init__(self, size):
    ...           assert size > 0
    ...           self._size = float(size)
    ...           self._content = float(0.0)
    ...       def __repr__(self):
    ...           if self._content == 0.0:
    ...               return "An empty glass of size %s"%(self._size)
    ...           else:
    ...               return "A glass of size %s cl containing %s cl of water"%(
    ...                       self._size, self._content)
    ...       def fill(self):
    ...           self._content = self._size
    ...       def empty(self):
    ...           self._content = float(0.0)

Let's create a small glass:

.. link

::

    sage: myGlass = Glass(10); myGlass
    An empty glass of size 10.0
    sage: myGlass.fill(); myGlass
    A glass of size 10.0 cl containing 10.0 cl of water
    sage: myGlass.empty(); myGlass
    An empty glass of size 10.0

Some comments:

1. The method ``__init__`` is used to initialize the object, it is used by the
   so called **constructor** of the class that is executed when calling ``Glass(10)``.

#. The method ``__repr__`` is supposed to return a string which is used to
   print the object.

.. note:: **Private Attributes**

   .. _private_attributes:

   - most of the time, the user should not change directly the
     attribute of an object. Those attributes are called **private**. Since
     there is no mechanism to ensure privacy in python, the usage is to prefix
     the name by an underscore.

   - as a consequence attribute access is only made through methods.

   - methods which are only for internal use are also prefixed with an
     underscore.

Exercises
---------

1. add a method ``is_empty`` which returns true if a glass is empty.

#. define a method ``drink`` with a parameter ``amount`` which allows to
   partially drink the water in the glass. Raise an error if one asks to
   drink more water than there is in the glass or a negative amount of
   water.

#. Allows the glass to be filled with wine, beer or other beverage. The method
   ``fill`` should accept a parameter ``beverage``. The beverage is stored in
   an attribute ``_beverage``. Update the method ``__repr__`` accordingly.

#. Add an attribute ``_clean`` and methods ``is_clean`` and ``wash``. At the
   creation a glass is clean, as soon as it's filled it becomes dirty, and must
   be washed to become clean again.

#. Test everything.

#. Make sure that everything is tested.

#. Test everything again.


Inheritance
===========

The problem: object of **different** classes may share a **common behavior**.

For example, if one wants to deal now with different dishes (forks, spoons
...) then there is common behavior (becoming dirty and being washed). So the
different classes associated to the different kinds of dishes should have the
same ``clean``, ``is_clean`` and ``wash`` methods. But copying and pasting
code is bad and evil ! This is done by having a base class which factorizes
the common behavior::

    sage: class AbstractDish(object):
    ...       def __init__(self):
    ...           self._clean = True
    ...       def is_clean(self):
    ...           return self._clean
    ...       def state(self):
    ...           return "clean" if self.is_clean() else "dirty"
    ...       def __repr__(self):
    ...           return "An unspecified %s dish"%self.state()
    ...       def _make_dirty(self):
    ...           self._clean = False
    ...       def wash(self):
    ...           self._clean = True

Now one can reuse this behavior within a class ``Spoon``:

.. link

::

    sage: class Spoon(AbstractDish):
    ...       def __repr__(self):
    ...           return "A %s spoon"%self.state()
    ...       def eat_with(self):
    ...           self._make_dirty()

Let's tests it:

.. link

::

    sage: s = Spoon(); s
    A clean spoon
    sage: s.is_clean()
    True
    sage: s.eat_with(); s
    A dirty spoon
    sage: s.is_clean()
    False
    sage: s.wash(); s
    A clean spoon

Summary
-------

1. Any class can reuse the behavior of another class. One says that the
   subclass **inherits** from the superclass or that it **derives** from it.

#. Any instance of the subclass is also an instance its superclass:

   .. link

   ::

        sage: type(s)
        <class '__main__.Spoon'>
        sage: isinstance(s, Spoon)
        True
        sage: isinstance(s, AbstractDish)
        True

#. If a subclass redefines a method, then it replaces the former one. One says
   that the subclass **overloads** the method. One can nevertheless explicitly
   call the hidden superclass method.

   .. link

   ::

        sage: s.__repr__()
        'A clean spoon'
        sage: Spoon.__repr__(s)
        'A clean spoon'
        sage: AbstractDish.__repr__(s)
        'An unspecified clean dish'

.. note:: **Advanced superclass method call**

   Sometimes one wants to call an overloaded method without knowing in which
   class it is defined. On use the ``super`` operator

   .. link

   ::


        sage: super(Spoon, s).__repr__()
        'An unspecified clean dish'

   A very common usage of this construct is to call the __init__ method of the
   super classes:

   .. link

   ::

        sage: class Spoon(AbstractDish):
        ...       def __init__(self):
        ...           print "Building a spoon"
        ...           super(Spoon, self).__init__()
        ...       def __repr__(self):
        ...           return "A %s spoon"%self.state()
        ...       def eat_with(self):
        ...           self.make_dirty()
        sage: s = Spoon()
        Building a spoon
        sage: s
        A clean spoon

Exercises
---------

1. Modify the class ``Glasses`` so that it inherits from ``Dish``.

#. Write a class ``Plate`` whose instance can contain any meals together with
   a class ``Fork``. Avoid at much as possible code duplication (hint:
   you can write a factorized class ``ContainerDish``).

#. Test everything.


.. _sage_specifics:

Sage specifics about classes
============================

Compared to Python, Sage has its particular way to handles objects:

- Any classes for mathematical objects in Sage should inherits from
  ``SageObject`` rather than from ``object``.

- Printing should be done through ``_repr_`` instead of ``__repr__`` to allows
  for renaming.

- More generally, Sage specific special methods are usually named ``_meth_``
  rather than ``__meth__``. For example, lots of classes implement ``_hash_``
  which is used and cached by ``__hash__``.

.. _solutions:

Solutions to the exercises
==========================

1. Here is a solution to the first exercise::

       sage: class Glass(object):
       ...       def __init__(self, size):
       ...           assert size > 0
       ...           self._size = float(size)
       ...           self.wash()
       ...       def __repr__(self):
       ...           if self._content == 0.0:
       ...               return "An empty glass of size %s"%(self._size)
       ...           else:
       ...               return "A glass of size %s cl containing %s cl of %s"%(
       ...                       self._size, self._content, self._beverage)
       ...       def content(self):
       ...           return self._content
       ...       def beverage(self):
       ...           return self._beverage
       ...       def fill(self, beverage = "water"):
       ...           if not self.is_clean():
       ...               raise ValueError, "Don't want to fill a dirty glass"
       ...           self._clean = False
       ...           self._content = self._size
       ...           self._beverage = beverage
       ...       def empty(self):
       ...           self._content = float(0.0)
       ...       def is_empty(self):
       ...           return self._content == 0.0
       ...       def drink(self, amount):
       ...           if amount <= 0.0:
       ...               raise ValueError, "amount must be positive"
       ...           elif amount > self._content:
       ...               raise ValueError, "not enough beverage in the glass"
       ...           else:
       ...               self._content -= float(amount)
       ...       def is_clean(self):
       ...           return self._clean
       ...       def wash(self):
       ...           self._content = float(0.0)
       ...           self._beverage = None
       ...           self._clean = True

#. Let's check that everything is working as expected:

   .. link

   ::

       sage: G = Glass(10.0)
       sage: G
       An empty glass of size 10.0
       sage: G.is_empty()
       True
       sage: G.drink(2)
       Traceback (most recent call last):
       ...
       ValueError: not enough beverage in the glass
       sage: G.fill("beer")
       sage: G
       A glass of size 10.0 cl containing 10.0 cl of beer
       sage: G.is_empty()
       False
       sage: G.is_clean()
       False
       sage: G.drink(5.0)
       sage: G
       A glass of size 10.0 cl containing 5.0 cl of beer
       sage: G.is_empty()
       False
       sage: G.is_clean()
       False
       sage: G.drink(5)
       sage: G
       An empty glass of size 10.0
       sage: G.is_clean()
       False
       sage: G.fill("orange juice")
       Traceback (most recent call last):
       ...
       ValueError: Don't want to fill a dirty glass
       sage: G.wash()
       sage: G
       An empty glass of size 10.0
       sage: G.fill("orange juice")
       sage: G
       A glass of size 10.0 cl containing 10.0 cl of orange juice

Here is the solution to the second exercice:

TODO !!!!

That all folks !
