
.. _tutorial-programming-python:

=========================================
Tutorial: Programming in Python with Sage
=========================================

:AUTHOR: Florent Hivert <florent.hivert@univ-rouen.fr>

This tutorial is an introduction to basic programming in Python/Sage. The
reader is supposed to know the elementary notions of programming but is not
supposed to be familiar with the python language. The memo given here are far
from being exhaustive. In case you need a more complete tutorial, you can have
a look at the `Python Tutorial
<http://docs.python.org/release/2.6.4/tutorial/index.html>`_. Also Python's
`documentation <http://docs.python.org/release/2.6.4/>`_ and in particular the
`standard library <http://docs.python.org/release/2.6.4/library>`_ can be
useful.

A :ref:`more advanced tutorial <tutorial-object-class>` present the notion of
objects and classes in Python.


Here is a further list of resources for people wanting to learn Python:

* `Learn Python in 10 minutes
  <http://www.korokithakis.net/tutorials/python>`_ ou en français
  `Python en 10 minutes
  <http://mat.oxyg3n.org/index.php?post/2009/07/26/Python-en-10-minutes>`_
* `Dive into Python <http://diveintopython.org/>`_
  is a Python book for experienced programmers. Also available in French,
  `Plongez au coeur de Python <http://diveintopython.adrahon.org/>`_, and
  `other languages <http://diveintopython.org/#languages>`_.
* `Discover Python
  <http://www.ibm.com/developerworks/views/opensource/libraryview.jsp?search_by=Discover+Python+Part|>`_
  is a series of articles published in IBM's `developerWorks
  <http://www.ibm.com/developerworks/>`_ technical resource center.



Data structures
===============


In Python, *typing is dynamic*; there is no such thing as declaring
variables. The function ``type`` returns the type of an object ``obj``. To
convert an object to a type ``typ`` just write ``typ(obj)`` as in
``int("123")``. The command ``isinstance(ex, typ)`` returns whether the
expression ``ex`` is of type ``typ``. Specifically, any value is *an instance
of a class* and there is no difference between class and types.

The symbol ``=`` design the affectation to a variable; it should not be
confused with ``==`` which design the mathematical equality. Inequality is
``!=``.

The *standard types* are ``bool``, ``int``, ``list``, ``tuple``, ``set``,
``dict``, ``str``.

* The type ``bool`` (*Booleans*) takes two values: ``True`` and ``False``. The
  boolean operator are denoted by their name ``or``, ``and``, ``not``.

* Sage uses *exact arithmetic* on the integers. For performance reason, it
  uses its own type named ``Integer`` (whereas \python uses the types ``int``
  and ``long``).

* A *list* is a data structure which groups values. It is constructed using
  brackets as in ``[1, 3, 4]``. The ``range`` function creates integer
  lists. One can also create lists using *list comprehension*::

      [ <expr> for <name> in <iterable> (if <condition>) ]

  For example::

      sage: [ i^2 for i in range(10) if i % 2 == 0 ]
      [0, 4, 16, 36, 64]


* A *tuple* is very similar to list; it uses parentheses. The empty tuple is
  obtained by ``()`` or by the constructor ``tuple()``. If there is only one
  element one has to write ``(a,)``. A tuple is *immutable* (one cannot
  change it) but it is *hashable* (see below). One can also create tuples
  using comprehension with the constructor::

      sage: tuple(i^2 for i in range(10) if i % 2 == 0)
      (0, 4, 16, 36, 64)

* A *set* is a data structure which contains values without multiplicities or
  order. One create it from a list (or any iterable) with the
  constructor ``set()``. The element of a set must be hashable.

      sage: set([2,2,1,4,5])
      set([1, 2, 4, 5])

* A *dictionary* is an association table, which associate values to
  keys. keys must be hashable. One create dictionnaire using the constructor
  ``dict`` or using the syntax::

      {key1 : value1, key2 : value2 ...}

  For example::

      sage: age = {'toto' : 8, 'mom' : 27}; age
      {'toto': 8, 'mom': 27}

* Quotes, simple ``' '`` or double ``" "`` encloses *character strings*. One
  can concatenate them using ``+``.

* For lists, tuples, strings, and dictionaries, the *indexing operator* is
  written ``l[i]``. For lists, tuples, and string one can also uses *slices*
  as ``l[:]``, ``l[:b]``, ``l[a:]`` ou ``l[a:b]``. Negative indexes start from
  the end.

* The ``len`` function returns the number of elements of a list, a tuple, a
  set, a string, or a dictionary. One writes ``x in C`` to tests whether ``x``
  is in ``C``.

* Finally there is a special value called ``None`` to denote the absence of a
  value. 


Control structures
==================

In Python, there is no keyword for the beginning and the end of an
instructions block. Block are delimited thanks to indentation. Most of the
time a new block is introduced by ``:``. Python has the following control
structure:

* Conditional instruction::

     if <condition>:
         <instruction sequence>
     [elif <condition>:
         <instruction sequence>]*
     [else:
         <instruction sequence>]

* inside expression exclusively, one can write::

   <value> if <condition> else <value>

* Iterative instructions::

     for <name> in <iterable>:
         <instruction sequence>
     [else:
         <instruction sequence>]

  ::

     while <condition>:
         <instruction sequence>
     [else:
         <instruction sequence>]

  The ``else`` bloc is executed at the end of the loop if the loop is ended
  normally, that is neither by a ``break`` of an exception.

* In a loop ``continue`` jump to the next iteration.

* An iterable is an object which can be iterated. Iterable types includes
  lists, tuples, dictionaries and strings.

* An error (also called exception) is raised by::

     raise <ErrorType> [, error message]

  Usual error includes ``ValueError`` and ``TypeError``.

Functions
=========

.. note:: Python functions vs. mathematical functions

    In what follows, we deal with *functions* is the sense of *programming
    languages*. Mathematical function are handled by sage in a different
    way. In particular it doesn't make sense to do mathematical manipulation
    such as addiction or derivation on those kinds of functions.

One defines function using the keyword ``def`` as ::

    def <name>(<argument list>):
         <instruction sequence>

The result of the function is given thank to the instruction ``return``. When
a function is very short, one can define anonymous function using ``lambda``
(remark that there is no return here)::

    lambda <arguments>: <expression>

.. note:: (functional programming)

    Functions are objects as any other objects. On can assign them to
    variables return them.


Exercises
=========

Lists
===============


Creating Lists I: [Square brackets]
-----------------------------------


**Example:**


::

    sage: L = [3, Permutation([5,1,4,2,3]), 17, 17, 3, 51]
    sage: L
    [3, [5, 1, 4, 2, 3], 17, 17, 3, 51]



**Exercise:** Create the list ``[63, 12, -10, 'a', 12]``, assign it to the
variable ``L``, and print the list.

::

    sage:


**Exercise:** Create the empty list. (You will often need to do this.)

::

    sage:


Creating Lists II: range
------------------------

The *range* function provides an easy way to construct a list of
integers. Here is the documentation of the *range* function. Here is the
inline documentation of the *range* functions::

    range([start,] stop[, step]) -> list of integers

    Return a list containing an arithmetic progression of integers.
    range(i, j) returns [i, i+1, i+2, ..., j-1]; start (!) defaults to 0.
    When step is given, it specifies the increment (or decrement). For
    example, range(4) returns [0, 1, 2, 3].  The end point is omitted!
    These are exactly the valid indices for a list of 4 elements.


**Exercise:** Use *range* to construct the list `[1,2,\ldots,50]`.

::

    sage:

**Exercise:** Use *range* to construct the list of *even* numbers between 1
and 100 (including 100).

::

    sage:

**Exercise:** The *step* argument for the *range* command can be negative. Use
*range* to construct the list `[10, 7, 4, 1, -2]`.

::

    sage:

Creating Lists III: list comprehensions
---------------------------------------


*List comprehensions* provide a concise way to create lists from other lists
(or other data types).


**Example** We already know how to create the list `[1, 2, \dots, 16]`:

::

    sage: range(1,17)
    [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16]

Using a *list comprehension*, we can now create the list
`[1^2, 2^2, 3^2, \dots, 16^2]` as follows

::

    sage: [i^2 for i in range(1,17)]
    [1, 4, 9, 16, 25, 36, 49, 64, 81, 100, 121, 144, 169, 196, 225, 256]


::

    sage: sum([i^2 for i in range(1,17)])
    1496

**Exercice:**

The sum of the squares of the first ten natural numbers is

          `(1^2 + 2^2 + ... + 10^2) = 385`

The square of the sum of the first ten natural numbers is

          `(1 + 2 + ... + 10)^2 = 55^2 = 3025`

Hence the difference between the sum of the squares of the first ten natural
numbers and the square of the sum is

          `3025 - 385 = 2640`

Find the difference between the sum of the squares of the first one hundred
natural numbers and the square of the sum.

::

    sage:

::

    sage:

::

    sage:


Filtering lists with a list comprehension
.........................................


A list can be *filtered* using a list comprehension.


**Example:** To create a list of the squares of the prime numbers between 1
and 100, we use a list comprehension as follows.

::

    sage: [p^2 for p in [1,2,..,100] if is_prime(p)]
    [4, 9, 25, 49, 121, 169, 289, 361, 529, 841, 961, 1369, 1681, 1849, 2209, 2809, 3481, 3721, 4489, 5041, 5329, 6241, 6889, 7921, 9409]



**Exercise:** Use a *list comprehension* to list all the natural numbers below
20 that are multiples of 3 or 5. Hint:

   * To get the remainder of 7 divided by 3 use *7%3*.
   * To test for equality use two equal signs (*==*); for example, *3 == 7*.

::

    sage:



Nested list comprehensions
..........................


List comprehensions can be nested!


**Examples:**


::

    sage: [(x,y) for x in range(5) for y in range(3)]
    [(0, 0), (0, 1), (0, 2), (1, 0), (1, 1), (1, 2), (2, 0), (2, 1), (2, 2), (3, 0), (3, 1), (3, 2), (4, 0), (4, 1), (4, 2)]



::

    sage: [[i^j for j in range(1,4)] for i in range(6)]
    [[0, 0, 0], [1, 1, 1], [2, 4, 8], [3, 9, 27], [4, 16, 64], [5, 25, 125]]



::

    sage: matrix([[i^j for j in range(1,4)] for i in range(6)])
    [  0   0   0]
    [  1   1   1]
    [  2   4   8]
    [  3   9  27]
    [  4  16  64]
    [  5  25 125]



**Exercise:**


A *Pythagorean triple* is a triple `(x,y,z)` of *positive* integers satisfying
`x^2+y^2=z^2`. The Pythagorean triples whose components are at most `10` are:

        `[(3, 4, 5), (4, 3, 5), (6, 8, 10), (8, 6, 10)]\,.`

Using a filtered list comprehension, construct the list of Pythagorean triples
whose components are at most `50`.

::

    sage:

::

    sage:



Accessing individual elements of lists
--------------------------------------


To access an element of the list, use the syntax ``L[i]``, where `i` is the
index of the item.


**Exercise:**

   1. Construct the list ``L = [1,2,3,4,3,5,6]``. What is ``L[3]``?

      ::

         sage:

   #. What is ``L[1]``?

      ::

         sage:

   #. What is the index of the first element of ``L``?

      ::

         sage:

   #. What is ``L[-1]``? What is ``L[-2]``?

      ::

         sage:

   #. What is ``L.index(2)``? What is ``L.index(3)``?

      ::

         sage:


Modifying lists: changing an element in a list
----------------------------------------------


To change the item in position ``i`` of a list ``L``:


::

    sage: L = ["a", 4, 1, 8]
    sage: L
    ['a', 4, 1, 8]

.. link

::

    sage: L[2] = 0
    sage: L
    ['a', 4, 0, 8]



Modifying lists: append and extend
----------------------------------

To *append* an object to a list:

::

    sage: L = ["a", 4, 1, 8]
    sage: L
    ['a', 4, 1, 8]

.. link

::

    sage: L.append(17)
    sage: L
    ['a', 4, 1, 8, 17]



To *extend* a list by another list:


::

    sage: L1 = [1,2,3]
    sage: L2 = [7,8,9,0]
    sage: print L1
    [1, 2, 3]
    sage: print L2
    [7, 8, 9, 0]

.. link

::

    sage: L1.extend(L2)
    sage: L1
    [1, 2, 3, 7, 8, 9, 0]



Modifying lists: reverse, sort, ...
-----------------------------------


::

    sage: L = [4,2,5,1,3]
    sage: L
    [4, 2, 5, 1, 3]

.. link

::

    sage: L.reverse()
    sage: L
    [3, 1, 5, 2, 4]

.. link

::

    sage: L.sort()
    sage: L
    [1, 2, 3, 4, 5]

::

    sage: L = [3,1,6,4]
    sage: sorted(L)
    [1, 3, 4, 6]

.. link

::

    sage: L
    [3, 1, 6, 4]

Concatenating Lists
-------------------


To concatenate two lists, add them with the operator ``+``. This is not a commutative operation....

::

    sage: L1 = [1,2,3]
    sage: L2 = [7,8,9,0]
    sage: L1 + L2
    [1, 2, 3, 7, 8, 9, 0]


Slicing Lists
---------------


You can slice a list using the syntax ``L[start : stop : step]``. This will
return a sublist of ``L``.


**Exercise:** Below are some examples of slicing lists. Try to guess what the output will be before evaluating the cell.

::

    sage: L = range(20)
    sage: L
    [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19]

.. link

::

    sage: L[3:15]
    [3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14]

.. link

::

    sage: L[3:15:2]
    [3, 5, 7, 9, 11, 13]

.. link

::

    sage: L[15:3:-1]
    [15, 14, 13, 12, 11, 10, 9, 8, 7, 6, 5, 4]

.. link

::

    sage: L[:4]
    [0, 1, 2, 3]

.. link

::

    sage: L[:]
    [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19]

.. link

::

    sage: L[::-1]
    [19, 18, 17, 16, 15, 14, 13, 12, 11, 10, 9, 8, 7, 6, 5, 4, 3, 2, 1, 0]


**Advanced exercise:** The following function combines a loop with the some of
the list operations above. What does the function do?

::

    sage: def f(number_of_iterations):
    ...       L = [1]
    ...       for n in range(2, number_of_iterations):
    ...           L = [sum(L[:i]) for i in range(n-1, -1, -1)]
    ...       return numerical_approx(2*L[0]*len(L)/sum(L), digits=50)

.. link

::

    sage: f(10)
    3.1413810483870967741935483870967741935483870967742


===============
Tuples
===============


A *tuple* is an *immutable* list. That is, it cannot be changed once it is
created. The syntax for creating a tuple is to the use parentheses.

::

    sage: t = (3, 5, [3,1], (17,[2,3],17), 4)
    sage: t
    (3, 5, [3, 1], (17, [2, 3], 17), 4)

We can create a tuple from a list, or vice-versa.

.. link

::

    sage: tuple(range(5))
    (0, 1, 2, 3, 4)

.. link

::

    sage: list(t)
    [3, 5, [3, 1], (17, [2, 3], 17), 4]


Tuples behave like lists in many respects:

+--------------------+-----------------------+-----------------------+
| Operation          | Syntax for lists      | Syntax for tuples     |
+====================+=======================+=======================+
| Accessing a letter | ``list[3]``           | ``tuple[3]``          |
+--------------------+-----------------------+-----------------------+
| Concatenation      | ``list1 + list2``     | ``tuple1 + tuple2``   |
+--------------------+-----------------------+-----------------------+
| Slicing            | ``list[3:17:2]``      | ``tuple[3:17:2]``     |
+--------------------+-----------------------+-----------------------+
| A reversed copy    | ``list[::-1]``        | ``tuple[::-1]``       |
+--------------------+-----------------------+-----------------------+
| Length             | ``len(list)``         | ``len(tuple)``        |
+--------------------+-----------------------+-----------------------+

Trying to modify a tuple will fail.


::

    sage: t = (5, 'a', 6/5)
    sage: t
    (5, 'a', 6/5)

.. link

::

    sage: t[1] = 'b'
    Traceback (most recent call last):
    ...
    TypeError: 'tuple' object does not support item assignment


Generators
==========

"Tuple-comprehension" does not exist.  The syntax produces something called a
generator.  A generator allows you to process a sequence of items one at a
time.  Each item is created when it is needed, and then forgotten.  This can
be very efficient if we only need to use each item once.

::

    sage: (i^2 for i in range(5))
    <generator object <genexpr> at 0x...>

::

    sage: g = (i^2 for i in range(5))
    sage: g[0]
    Traceback (most recent call last):
    ...
    TypeError: 'generator' object is unsubscriptable

.. link

::

    sage: [x for x in g]
    [0, 1, 4, 9, 16]

``g`` is now empty.

.. link

::

    sage: [x for x in g]
    []

A nice 'pythonic' trick is to use generators as the argument to functions.  We
do *not* need double parentheses for this.

::

    sage: sum( i^2 for i in srange(100001) )
    333338333350000

===============
Dictionaries
===============


A *dictionary* is another built-in data type. Unlike lists, which are indexed by a range of numbers, dictionaries are "indexed" by *keys*, which can be any immutable object. Strings and numbers can always be keys (because they are immutable). Dictionaries are sometimes called "associative arrays" in other programming languages.


There are several ways to define dictionaries. One method is to use braces, {}, with comma-separated entries given in the form *key:value*.


::

    sage: d = {3:17, "key":[4,1,5,2,3], (3,1,2):"goo", 3/2 : 17}
    sage: d
    {3/2: 17, 3: 17, (3, 1, 2): 'goo', 'key': [4, 1, 5, 2, 3]}


Dictionaries behave as lists and tuples for several important operations.

+--------------------+-----------------------+-----------------------------+
| Operation          | Syntax for lists      | Syntax for dictionaries     |
+====================+=======================+=============================+
| Accessing elements | ``list[3]``           | ``D["key"]``                |
+--------------------+-----------------------+-----------------------------+
| Length             | ``len(list)``         | ``len(D)``                  |
+--------------------+-----------------------+-----------------------------+
| Modifying          | ``L[3] = 17``         | ``D["key"] = 17``           |
+--------------------+-----------------------+-----------------------------+
| Deleting items     | ``del L[3]``          | ``del D["key"]``            |
+--------------------+-----------------------+-----------------------------+

.. link

::

    sage: d[10]='a'
    sage: d
    {3/2: 17, 10: 'a', 3: 17, (3, 1, 2): 'goo', 'key': [4, 1, 5, 2, 3]}


A dictionary can have the same value multiple times, but each key can only
appear once and must be immutable.

::

    sage: d = {3: 14, 4: 14}
    sage: d
    {3: 14, 4: 14}

::

    sage: d = {3: 13, 3: 14}
    sage: d
    {3: 14}

::

    sage: d = {[1,2,3] : 12}
    Traceback (most recent call last):
    ...
    TypeError: unhashable type: 'list'


Another way to add items to a dictionary is with the ``update()`` method:


::

    sage: d = {}
    sage: d
    {}

.. link

::

    sage: d.update( {10 : 'newvalue', 20: 'newervalue', 3: 14, 'a':[1,2,3]} )
    sage: d
    {'a': [1, 2, 3], 10: 'newvalue', 3: 14, 20: 'newervalue'}


We can iterate through the *keys*, or *values*, or both, of a dictionary.

::

    sage: d = {10 : 'newvalue', 20: 'newervalue', 3: 14, 'a':[1,2,3]}

.. link

::

    sage: [key for key in d]
    ['a', 10, 3, 20]

.. link

::

    sage: [key for key in d.iterkeys()]
    ['a', 10, 3, 20]

.. link

::

    sage: [value for value in d.itervalues()]
    [[1, 2, 3], 'newvalue', 14, 'newervalue']

.. link

::

    sage: [(key, value) for key, value in d.iteritems()]
    [('a', [1, 2, 3]), (10, 'newvalue'), (3, 14), (20, 'newervalue')]


**Exercise:** Consider the following directed graph.

.. image:: media/graph0.png


Create a dictionary whose keys are the vertices of the above directed graph,
and whose values are the lists of the vertices that it points to. For
instance, the vertex 1 points to the vertices 2 and 3, so the dictionary will
look like::

    d = { ..., 1:[2,3], ... }

::

    sage:

Then try

.. skip

::

    sage: g = DiGraph(d)
    sage: g.plot()


Using Sage types: The srange command
====================================

**Example:** Construct a `3 \times 3` matrix whose `(i,j)` entry is the
rational number `\frac{i}{j}`. The integer generated by ``range`` are
python ``int``. As a consequence, dividing them does euclidian division.

::

    sage: matrix([[ i/j for j in range(1,4)] for i in range(1,4)])
    [1 0 0]
    [2 1 0]
    [3 1 1]

Whereas Dividing sage ``Integer`` gives a fraction

::

    sage: matrix([[ i/j for j in srange(1,4)] for i in srange(1,4)])
    [  1 1/2 1/3]
    [  2   1 2/3]
    [  3 3/2   1]



Modifying lists has consequences!
=================================

Try to predict the results of the following commands.

::

    sage: a = [1, 2, 3]
    sage: L = [a, a, a]
    sage: L
    [[1, 2, 3], [1, 2, 3], [1, 2, 3]]

.. link

::

    sage: a.append(4)
    sage: L
    [[1, 2, 3, 4], [1, 2, 3, 4], [1, 2, 3, 4]]

Now try these:

::

    sage: a = [1, 2, 3]
    sage: L = [a, a, a]
    sage: L
    [[1, 2, 3], [1, 2, 3], [1, 2, 3]]

.. link

::

    sage: a = [1, 2, 3, 4]
    sage: L
    [[1, 2, 3], [1, 2, 3], [1, 2, 3]]

.. link

::

    sage: L[0].append(4)
    sage: L
    [[1, 2, 3, 4], [1, 2, 3, 4], [1, 2, 3, 4]]

You can use the command *deepcopy* to avoid these issues.

::

    sage: a = [1,2,3]
    sage: L = [deepcopy(a), deepcopy(a)]
    sage: L
    [[1, 2, 3], [1, 2, 3]]

.. link

::

    sage: a.append(4)
    sage: L
    [[1, 2, 3], [1, 2, 3]]


The same issues occur with dictionaries.

::

    sage: d = {1:'a', 2:'b', 3:'c'}
    sage: dd = d
    sage: d.update( { 4:'d' } )
    sage: dd
    {1: 'a', 2: 'b', 3: 'c', 4: 'd'}

