#!/usr/bin/env python
import os, sys

fname = sys.argv[1]
input = open(fname, "r")
output = open(fname + ".fixed","w")
output.write("\\documentclass{beamer}\n\\usepackage{appearance}\n\\newcommand\\reals{\\mathbb R}\n\\begin{document}\n")
for s in input.xreadlines():
  s = s.replace("TitleSlide","title")
  s = s.replace("StartSlide","lyxframe")
  s = s.replace("NewSlide","lyxframe")
  s = s.replace("StartOverlaySlide","lyxframe")
  s = s.replace("OverlaySlide","pause")
  s = s.replace("scale=0.6","scale=0.3")
  s = s.replace("scale=0.4","scale=0.3")
  s = s.replace("\\colorbox{boxcolor}{","")
  s = s.replace("\\colorbox{whitecolor}{","")
  s = s.replace("\\capfont","")
  s = s.replace("\\parbox[t]{13cm}{","")
  s = s.replace("}}}\\end{center}\\end{figure}","\\end{center}\\end{figure}")
  s = s.replace("\\\\]","]")
  s = s.replace("\\input{lib/instructions}","")
  s = s.replace("\\BCitem","\\begin{itemize}")
  s = s.replace("\\ECitem","\\end{itemize}")
  s = s.replace("%++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++","")
  output.write(s)
output.write("\\lyxframeend{}\n\\end{document}\n")
output.close()
input.close()
